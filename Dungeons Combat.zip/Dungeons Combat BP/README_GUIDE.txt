Welcome, and thanks for playing & using Dungeons Combat Addon!
This README entails (maybe) everything needed for the behavior pack / server-side modification of the addon. For visual effects and graphics, check the resoruce pack!

0. Beginning

Minecraft Dungeons have top-down isometric-like camera view. Recommeneded FOV is 38'.